---
layout: home
hero:
  name: Omega MVC
  text: PHP 8.4+ MVC Framework
  tagline: Lightweight, modular, and fast.
  actions:
    - theme: brand
      text: Application
      link: /Application
    - theme: alt
      text: GitHub
      link: https://github.com/omega-mvc/framework
---
